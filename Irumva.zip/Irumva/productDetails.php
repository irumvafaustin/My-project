<?php
   include("config1.php");
   $id = $_GET['id'];
   $query = "SELECT * FROM productivity WHERE productid =".$id;
   
   $result = mysqli_query ($connection, $query);
   if(!$result){
	   echo "Error ".mysqli_error($connection);
   }else{
	   while($row=mysqli_fetch_array($result)){
		    echo "<br/><hr/>";
		   echo "Product ID: ".$row['productid']; echo "<br/>";
		   echo "Product Name: ".$row['productname']; echo "<br/>";
         echo "Product quantity: ".$row['productquantity']; echo "<br/>";
		   echo "Product Price: ".$row['productprice']; echo "<br/>";
         echo "Product image: ".$row['image']; echo "<br/>";
         echo "Product category: ".$row['productcategory']; echo "<br/>";
	   }
   }
?>