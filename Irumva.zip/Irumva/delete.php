<?php
  include_once 'config1.php';
  $id=$_GET['id'];
  $sql="DELETE FROM fregister WHERE id=$id";
  mysqli_query($connection,$sql);
  header("location:farmer.php");
  exit();
?>