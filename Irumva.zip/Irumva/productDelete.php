<?php
  include("config1.php");
  $id =$_GET['id'];
  
  $query = "DELETE FROM productivity WHERE productid=".$id;
  //echo $query;
  
  $r = mysqli_query($connection, $query);
  
  if($r){
	  echo "record deleted";
  }else{
	  echo "  oops Something went wrong!  please try again";
  }

?>