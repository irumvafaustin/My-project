-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 04:54 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `adminemail` varchar(25) NOT NULL,
  `adminpassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminemail`, `adminpassword`) VALUES
(1, 'faustin@gmail.com', 'fausti123');

-- --------------------------------------------------------

--
-- Table structure for table `fregister`
--

CREATE TABLE `fregister` (
  `id` int(20) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(14) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Category` varchar(15) NOT NULL,
  `Country` varchar(10) NOT NULL,
  `Provence` varchar(15) NOT NULL,
  `District` varchar(15) NOT NULL,
  `Sector` varchar(15) NOT NULL,
  `Cell` varchar(15) NOT NULL,
  `Village` varchar(15) NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fregister`
--

INSERT INTO `fregister` (`id`, `Fname`, `Lname`, `Email`, `Password`, `Gender`, `Category`, `Country`, `Provence`, `District`, `Sector`, `Cell`, `Village`, `phone`, `age`) VALUES
(3, 'kazungu', 'kazungu', 'kazungu@gmail.com', 'NAime123!', 'Female', 'small', 'rwanda', 'western', 'nyabihu', 'bigogwe', 'kijote', 'zihari', NULL, NULL),
(4, 'irumva', 'faustin', 'faustin@gmail.com', '1234', 'Male', 'medium', 'rwanda', 'western', 'nyabihu', 'bigogwe', 'kijote', 'busasamana', NULL, NULL),
(5, 'irumva', 'faustin', 'wetdryc@dfhgf', '234', 'Male', 'marginal', 'rwanda', 'western', 'nyabihu', 'bigogwe', 'kijote', 'busasamana', NULL, NULL),
(6, 'kwibuka', 'olivier', 'kw@gmail.com', '12345', 'Female', 'semi-medium', 'rwanda', 'northern', 'musanze', 'muhoza', 'rwantobo', '', NULL, NULL),
(7, 'kazungu', 'Cantona', 'ericca@gmail.com', '13235', 'Male', 'small', 'rwanda', 'western', 'nyabihu', 'bigogwe', 'kijote', 'bukinanyana', NULL, NULL),
(8, 'kimenyi', 'honore', 'kimenyi@gmail.com', 'kimenyi', 'Male', 'medium', 'rwanda', 'northern', 'burera', 'gahunga', 'rwantobo', '', NULL, NULL),
(9, 'nizeyimana', 'aime', 'aime@gmail.com', 'aime', '', '', '', 'southern', 'muhanga', 'cyeza', '', '', NULL, NULL),
(10, 'nizeyimana', 'aime', 'aime@gmail.com', 'aime', '', '', 'rwanda', 'southern', 'muhanga', 'cyeza', '', '', NULL, NULL),
(11, 'natete', 'alexandre', 'natete@gmail.com', 'natete', '1', '6', 'rwanda', 'western', 'ngororero', 'gatumba', 'gasiza', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orderproduct`
--

CREATE TABLE `orderproduct` (
  `order_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` varchar(14) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderproduct`
--

INSERT INTO `orderproduct` (`order_id`, `name`, `code`, `quantity`, `unit_price`, `price`) VALUES
(1, 'pineapple', 'p002', 18, 800, 800),
(2, 'pineapple', 'p002', 18, 800, 800),
(3, 'pineapple', 'p002', 18, 800, 800),
(4, 'pineapple', 'p002', 18, 800, 800),
(5, 'plum', 'pl2', 1, 300, 300),
(6, 'plum', 'pl2', 1, 300, 300),
(7, 'plum', 'pl2', 1, 300, 300),
(8, 'plum', 'pl2', 1, 300, 300),
(9, 'plum', 'pl2', 1, 300, 300),
(10, 'plum', 'pl2', 1, 300, 300),
(11, 'plum', 'pl2', 1, 300, 300),
(12, 'plum', 'pl2', 1, 300, 300),
(13, 'plum', 'pl2', 1, 300, 300),
(14, 'plum', 'pl2', 1, 300, 300),
(15, 'plum', 'pl2', 1, 300, 300),
(16, 'plum', 'pl2', 1, 300, 300),
(17, 'plum', 'pl2', 1, 300, 300),
(18, 'plum', 'pl2', 1, 300, 300),
(19, 'plum', 'pl2', 1, 300, 300),
(20, 'plum', 'pl2', 1, 300, 300);

-- --------------------------------------------------------

--
-- Table structure for table `productivity`
--

CREATE TABLE `productivity` (
  `productid` int(20) NOT NULL,
  `productname` varchar(20) NOT NULL,
  `productquantity` int(14) NOT NULL,
  `productprice` varchar(10) NOT NULL,
  `image` varchar(20) NOT NULL,
  `productcategory` varchar(20) NOT NULL,
  `farmer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `productivity`
--

INSERT INTO `productivity` (`productid`, `productname`, `productquantity`, `productprice`, `image`, `productcategory`, `farmer_id`) VALUES
(1, '0', 3500, '250', 'khg', 'patatoes', 4),
(2, '0', 1234, '321', 'jfghs', 'fruit', 8),
(3, 'carrot', 3000, '20000', 'jfghs', 'fruit', NULL),
(4, 'patatoes', 123, '1234', 'we', 'patatoes', NULL),
(5, 'carrot', 7, '456', 'rtrtrt', 'patatoes', 8);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `sid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL,
  `phone` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `category` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`sid`, `name`, `email`, `password`, `phone`, `age`, `category`, `gender`) VALUES
(1, 'hirwa', 'hirwa@gmail', 'hirwa', 788, 23, 'large', 'male'),
(2, '', '', '', 0, 0, '', 'male'),
(3, '', '', '', 0, 0, '', 'male'),
(4, 'ingabire aime', 'ingabire@gmail.com', 'ingabire', 789900, 2000, '', 'female'),
(5, 'ingabire aime', 'ingabire@gmail.com', 'ingabire', 789900, 2000, '', 'female'),
(6, 'ange', 'vuyuyihujo@gmail.com', 'qwe', 12345, 2222, 'small', 'female'),
(7, 'ange', 'vuyuyihujo@gmail.com', 'qwe', 12345, 2222, 'small', 'female');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(1, 'carrot', '00ct1', 'product-images/carrot.jpg', 1500.00),
(2, 'cabbage', 'cbb1', 'product-images/cabbage.jpg', 800.00),
(3, 'plum', 'pl2', 'product-images/ibinyomoro.jpg', 300.00),
(4, 'pineapple', 'p002', 'product-images/inanasi.jpg', 800.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fregister`
--
ALTER TABLE `fregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `productivity`
--
ALTER TABLE `productivity`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fregister`
--
ALTER TABLE `fregister`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orderproduct`
--
ALTER TABLE `orderproduct`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `productivity`
--
ALTER TABLE `productivity`
  MODIFY `productid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
