<?php
$conn=mysqli_connect('localhost','root','','register');
$result=mysqli_query($conn,"select * from fregister");
?>
<html>
<head>

<style>
    table {
      border:1px;
    border-collapse: collapse;
    width: 100%;
    background-color:#f1f1f1;
  }
  
  th{
    text-align: left;
    padding: 8px;
    border-radius: 25px;
    background-color:white;
  }
  td:nth-child(even) {background-color:gray;}
  td:nth-child(odd) {background-color:gray;}
</style>

</head>
<body>


<header>
    <h2><img class="logo" src="agrilogo.jpg">agriculture</h2>
   
<div class="topnav">

  <a href="logout.php"  style="float: right;" >Logout</a>
 
  <a class="active" href="MY PROJECT2.php" style="float: left;" >Home</a><br/>
</div>
</header>
<section>
  <div>
    <nav>
      <ul>
        <li><a href="farmer.php" class="active">Farmer</a></li>
        <li><a href="seller.php">Seller</a></li>
    
      </ul>
    </nav>
    <div>
  <article>  
<table style="width:100%; border=1">
  <tr>
    <th>ID</th>
    <th>Fname</th>
    <th>Lname</th> 
    <th>Email</th>
    <th>Password</th>
    <th>gender</th>
    <th>category</th>
    <th>country</th> 
    <th>provence</th>
    <th>district</th>
    <th>sector</th>
    <th>cell</th>
    <th>village</th>
    <th>phone</th>
    <th>age</th>
    <th>delete</th>
    <th>update</th>
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['id'];?></td>
    <td><?php echo $row['Fname'];?></td>
    <td><?php echo $row['Lname'];?></td>
    <td><?php echo $row['Email'];?></td>
    <td><?php echo $row['Password'];?></td>
    <td><?php echo $row['Gender'];?></td>
    <td><?php echo $row['Category'];?></td>
    <td><?php echo $row['Country'];?></td>
    <td><?php echo $row['Provence'];?></td>
    <td><?php echo $row['District'];?></td>
    <td><?php echo $row['Sector'];?></td>
    <td><?php echo $row['Cell'];?></td>
    <td><?php echo $row['Village'];?></td>
    <td><?php echo $row['phone'];?></td>
    <td><?php echo $row['age'];?></td>
   
   <td> <form action="delete.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <a href="delete.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">DELETE</button>
                </form>
            </td>
    <td>
    <td><input type="hidden" name="id" value=<?php echo $row['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
    </form>
    </td>
  </tr>
  <?php endwhile;?>
</table>
  </article>
  </section>
  <center>
    <footer class="footer text-center">
      <div class="footer-top">
        <div class="row">
          <div class="col-md-offset-3 col-md-6 text-center">
            <div class="widget">
              <h4 class="widget-title"> .</h4>
              <p><a href="#"><i class="fa fa-street-view" aria-hidden="true"></i></a> <b></b><br><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a><b> </b><br><br><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a><b> </b><br><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>  </p>
              
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
              
              <p class="copyright clear-float">
               
                <div class="credits">
                  
                  Designed by faustin</a>
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    </center>
  </body>
  </html>
