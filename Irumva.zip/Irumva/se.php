<?php

$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$phone=$_POST['phone'];
$age=$_POST['age'];
$category=$_POST['category'];
$gender=$_POST['gender'];



$conn= new MySQLi('localhost','root','','register');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO seller (name,email,password,phone,age,category,gender)
VALUES ('$name','$email','$password','$phone','$age','$category','$gender')";

if (mysqli_query($conn, $sql)) {
	echo "Successfully Registerd<br><br>";
  echo "<a href=slogin.php>Login Now</a>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>