<style> 
body{
  color:#7098c2;
}
.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: green;
}
.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: DarkSlateBlue;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}
</style>
<div class="navbar">
  <a href="MY PROJECT2.php">Home</a>
  <div class="subnav">
    <button class="subnavbtn">FARMER <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="fregister.php">REGISTER</a>
      <a href="index.php">PRODACTIVITY</a>
	  <a href="flogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">SELLER<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      
    <a href="prod.html">online service</a>
    <a href="sregister.php">REGISTER</a>
      <a href="slogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">ADMIN <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="adminlogin.php">LOGIN</a>
      
    </div>
    </div>
    <div class="subnav">
    <button class="subnavbtn"> <a href="logout.php">LOGOUT<i class="fa fa-caret-down"></i></a></button>
    
  </div>
    
</div>
<?php
  session_start();
  include("config1.php");
  
?>
 <link rel="stylesheet" type="text/css" href="pro.css">
<form action="" method="post">
  <input type="text" name ="pname" placeholder="Enter the product name"/>
  <br/> 
    <input type="number" name ="pquantity" placeholder="Enter the quantity"/>
   <br/> 
   <input type="number" name ="pprice" placeholder="Enter the product price"/>
  <br/> 
    <input type="text" name ="image" placeholder="Enter the image"/>
   <br/>
   <input type="text" name ="pcategory" placeholder="Enter the category"/>
   <br/>
	<input type="submit" name ="submit" value="Save"/>
	<input type="submit" name ="retrieve" value="Retrieve"/>
</form>
<?php
$id=$_SESSION['user'];
   if(isset($_POST["submit"])){
	$pname = $_POST['pname'];
	$pquantity = $_POST['pquantity'];
		$pprice = $_POST['pprice'];
		$image = $_POST['image'];
		$pcategory = $_POST['pcategory'];
		
		$query= "INSERT INTO productivity (productname, productquantity,productprice,image,productcategory,farmer_id)
		VALUES ('$pname','$pquantity','$pprice','$image','$pcategory','$id');";
		
		$r = mysqli_query($connection, $query); 
	    if(!$r){
			echo "Failed ".mysqli_error($connection);
		}else{
			echo "Product saved";
		}
   }
   if(isset($_POST["retrieve"]))
   {
	   
	   $rqu = "SELECT * FROM product";
	   $result = mysqli_query($connection, $rqu);
	   ?>
	   <table border="1">
	     <tr>
		    <th>ID </th>
			<th>Product name </th>
			<th>Product quantity </th>
			<th>Product price </th>
			<th>image </th>
			<th>Product category </th>
			<th colspan="3">action </th>
		</tr> 
		<?php
		$sql = "SELECT productid, productname, productquantity,productprice,image,productcategory FROM productivity WHERE farmer_id=$id";
		$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>" . $row["productid"]. " </td>
	<td> " . $row["productname"]. " </td>
	<td>" . $row["productquantity"]. " </td>
	<td> " . $row["productprice"]. " </td>
	<td>" . $row["image"]. " </td>
	<td>" . $row["productcategory"]. "</td>"
	?>
	<td><a href="productDetails.php?id=<?php echo $row['productid'];?>"> view </a></td>
		   <td><a href="productUpdat.php?id=<?php echo $row['productid'];?>"> Update</a> </td>
		   <td><a href="productDelete.php?id=<?php echo $row['productid'];?>"> Delete </a></td>
		   <?php
	"<br/></tr>";
}
} else {
  echo "0 results";
}



   }
?>
</table>